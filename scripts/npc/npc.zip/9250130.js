
var status = 0;
var sel;

function start() {
	if (cm.getCQInfo(100008).contains("future")) {
		status = -1;
	} else if (cm.getCQInfo(100008).contains("success")) {
		status = 1;
	} else {
		status = 2;
	}
    action(1, 0, 0);
}

function action(mode, type, selection) {
    if (mode == -1) {
        cm.dispose();
    } else {
		if (status == 0 && mode == 0) {
			cm.sendNext("come back again later..");
			cm.dispose();
			return;
		}
        if (mode == 1) {
            status++;
		} else {
            status--;
		}
        if (status == 0) {
			cm.sendYesNo("how can I go to the Alien's MotherShip, and he will charge your 3 Zeta Residue for the answer. ");
		} else if (status == 1) {
			if (cm.haveItem(4031753, 3)) {
				cm.gainItem(4031753, -3);
				cm.sendNext("he will say that the MotherShip had crashed. To access the Crash Site, I must get the permission from Lily(Located at 502023000) who guard at the Energy Laboratory. The portal at >> will lead me to the Energy Laboratory");
				cm.updateCQInfo(100008, "paid");
			} else {
				cm.sendOk("error");
				// shouldn't happen
			}
			cm.dispose();
		} else if (status == 2) {
			cm.sendNext("your mission is now completed..you can enter the portal..etc");
			cm.dispose();
		} else if (status == 3) { // shouldn't come here
			cm.sendNext("quick hurry to the >>>>etc.");
			cm.dispose();
		}
	}
}