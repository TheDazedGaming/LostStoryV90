
var status = 0;
var sel;

function start() {
	if (cm.getPlayer().getMapId() == 502010040 && cm.isCQActive(100004)) {
		status = -1;
	} else if (cm.getPlayer().getMapId() == 502010200) {
		status = 1;
	} else if (cm.isCQFinished(100005) && cm.getCustomQuestStatus(100006) == 0) { // Completed quest 100004
		status = 3;
	} else if (cm.isCQActive(100006)) { // started occupation quest, time to explain havent select
		status = 4;
	} else if (cm.isCQFinished(100006)) { // all done here
		status = 5;
	} else {
		status = 6;
	}
    action(1, 0, 0);
}

function action(mode, type, selection) {
    if (mode == -1) {
        cm.dispose();
    } else {
        if (mode == 1) {
            status++;
		} else {
            status--;
		}
        if (status == 0) {
			cm.sendNext("Some kind of text...etc \"aliens are approaching near and we need to prepare..saw the machine there? I need some items so that I can give you special power for you to fight with the aliens..are you willing to help? etc (accept/decline) -> warp deep sea \"");
		} else if (status == 1) {
			if (cm.completeCQ(100004)) {
				cm.gainExp(100);
			}
			cm.startCQ(100005);
			cm.warp(502010200);
			cm.dispose();	
		} else if (status == 2) { // Second part
			if (!cm.haveItem(4032708, 10)) {
				cm.sendOk("I need you to collect 10 mainboard. also note that you're not being damaged..etc protected..by the suit...the aliens posses a 4031757 (Antellion Rellic) which will combine with the broken tubes there. Please drop thie item at each of the broken tubes and obtain 10 mainbaord for me");
				cm.dispose();
			} else {
				if (cm.completeCQ(100005)) {
					cm.gainExp(100); // fix
				}
				cm.sendNext("thank you, now let me get ready to cast the special power at the laboratory.");
			}
		} else if (status == 3) {
			cm.removeAll(4032708); //just incase
			cm.getPlayer().cancelMorphs(true);
			cm.warp(502010040);
			cm.dispose();
		} else if (status == 4) { // get ready to pick occupation
			cm.startCQ(100006);
			cm.sendNext("let me explain everything to you..etc etc etc etc.special powers, etc = in other words = occupation..let me fix my transformation tubes first. talk to me again later.");		
			cm.dispose();
		} else if (status == 5) {// explain.
			cm.sendNext("my work here is done! the laboratory tube is now completed. thank you for yor effort on helping me..now plesea talk to my specific helpers for more details.");
			cm.dispose();
		} else if (status == 6) {// picked occ and talk back to me again
			cm.sendNext("dr bing ..etc reach..you can enter his lab now..done research..");
			cm.dispose();
		} else { // shouldn't come here
			cm.sendNext("what are you doing here?..");
			cm.dispose();
		}
	}
}